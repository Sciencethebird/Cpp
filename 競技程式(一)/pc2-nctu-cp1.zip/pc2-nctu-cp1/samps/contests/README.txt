README
Sun Sep 18 18:08:43 PDT 2011

This directory contains sample contests.

contestinfo - a list of directories (order for picking these contests)

<dir>/contest.yaml  - general contest information

eof README $Id$

